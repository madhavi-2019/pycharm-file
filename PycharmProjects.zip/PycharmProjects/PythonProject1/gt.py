firstname=input("enter your fisrtname")
lastname=input("enter your lastname")
a="hello,congratulation"
print(a+firstname+lastname)
