x=8
y=10
print(x+y)
print(x-y)
print(x*y)
print(x/y)


